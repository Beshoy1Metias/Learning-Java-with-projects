/**
  *        FOUNDATIONS OF COMPUTER SCIENCE - A.A. 2024-25
  *                Programming Test - 03-09-2025
  *
  * Implements a queue, that is collection of items with FIFO (First In First
  * Out) access policy, where the first item inserted (front) is the first
  * extracted.
  *
  * @author A. Luchetta
  * @version 18-Jan-2025
  *
  */
// implemented using a circular array. Asymptotic time complexity of the dequeue
// methods is O(1) in all cases, of the enqueue method is O(1) in the average case
// and O(n) in the worst case.  
public class Q implements Queue // ADT Queue 
{

   // constants
   private static final int INITIAL_CAPACITY = 1;
   
   // instance variables
   private Comparable[] v;
   private int front, back;                  // circular array indexes
   

   /**
      Constructs an empty queue
   */
   public Q()
   {
      makeEmpty();
   }
   
   /**
      Returns true if the specified item is contained in this queue
      @param item the item to check
      @return true if the specified item is contained in this queue 
   */
   public boolean contains(Comparable item)
   {
      int i = front;
      while (i != back)
      {
         // current item
         Comparable curItem = (Comparable)v[i];    // tyoe cast is needed
         
         // check items
         if (curItem.equals(item)) return true;
         
         // increment circular index
         i = increment(i);
      }
      
      return false;
   }  
        
   /*
      Removes the front item from this queue and returns it.
      @return the removed front item of this queue or null if the this queue is empty.
   */
   public Comparable dequeue() // O(1) in all cases
   {
      // check preconditions
      if (isEmpty()) return null;
      
      // save current front item
      Comparable frontItem = front();
      
      // remove current front item
      v[front] = null;

      // move front index forward
      front = increment(front);
      
      return frontItem;
   }
   
   // increments index for circular array
   private int increment(int index)
   {
      return (index + 1) % v.length;
   }
   
   /**
      Inserts the specified item into this queue.
      @param item the specified item to be inserted.
      @throws java.lang.IllegalArgumentException if the specified item is null.
   */
   public void enqueue(Comparable item) throws IllegalArgumentException // O(n) in the worst case
   {
      // check preconditions
      if (item == null) throw new IllegalArgumentException();
      
      // dynamically resize if needed 
      if (isFull()) // O(n) in worst case
      {
         Comparable[] newV = new Comparable[2 * v.length];
         int i = front;      // index in new array
         int j = front;      // index in old array
         while (j != back)
         {
            // copy item from old to new array
            newV[i++] = v[j];

            // increment circular index
            j = increment(j);                        
         }
         
         // place back index - front is unchanged
         back = i; 
                 
         v = newV;
      }
           
      // insert new item
      v[back] = item;
      
      // increment circular back index
      back = increment(back);             
   }
   
   // checks if the circular array is full
   private boolean isFull()
   {
      return increment(back) == front;
   }
   
   /**
      Returns the front item of this queue.
      @return the front item of this queue or null if this queue is empty.
   */
   public Comparable front()
   {
      // check preconditions
      if (isEmpty()) return null;
      
      return (Comparable)v[front];    // type cast is needed
   }   
   
  /**
      Checks if this queue is empty.
      @return true if this queue is empty.
   */
   public boolean isEmpty()
   {
      return front == back;
   }
   
   /**
      Makes this queue empty.
   */
   public void makeEmpty()
   {
      // create inner array
      v = new Comparable[INITIAL_CAPACITY];
      
      // initialize circular array indexes
      front = back = 0;   
   }        
   
   /**
      Returns the number of items in this queue.
      @return number of items in this queue.
   */
   public int size()
   {
      int size;
      
      if (back >= front) size = back - front;
      else size = v.length - front + back;
      
      return size;
   }
   
   /*
      Returns the maximum item in this queue according to the natural ordering
      of the elements of this queue.
      @return the maximum data item in this queue or null if this queue is empty.
   */
   public Comparable maxItem()
   {
      // preconditions
      if (isEmpty()) return null;
      
      // search for max item
      Comparable maxItem = v[front];               // initial guess 
      int i = increment(front);    
      while (increment(i) != back)
      {
         Comparable curItem = v[i];       
         if (curItem.compareTo(maxItem) > 0) maxItem = curItem;
         
         i = increment(i);
      }
      
      return maxItem;
   }       
}  
