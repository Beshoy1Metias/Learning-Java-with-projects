/**
  *        FOUNDATIONS OF COMPUTER SCIENCE - A.A. 2024-25
  *                Programming Test - 03-09-2025
  *
  * Implements an extended queue.
  *
  * @author A. Luchetta
  * @version 18-Jan-2025
  *
  */
public class EQ extends Q
{
   /**
      Constructs an empty extended queue
   */
   public EQ()
   {
      super();
   }
   
   /**
      Constructs an extended queue with the same elements as the specified
      queue in the same FIFO sequence. If the specified queue is null,
      constructs an empty extended queue
      @param the specified extended queue
      @throws NullPointerException if the specified queue is null
   */
   public EQ(EQ q)
   {
      // construct an empty queue
      this();

      // preconditions
      if (q == null || q.isEmpty()) return;
      
      // retrive elements from specified queue
      Comparable[] v = q.toArray();
      
      // insert element into this queue
      for (Comparable c : v)
      {
         enqueue(c);
      }
   }
   
   /**
      Returns the maximum item in this extended queue - recursive implementation
      @return the maximum item in this extended queue if this extended queue in not
              empty or otherwise null
   */
   public Comparable maxItem()
   {
      // check preconditions
      if (isEmpty()) return null;
      
      // select max Item
      recursiveMaxItem();         // swaps this queue
      
      return recursiveMaxItem(); // returns max item after swapping again this queue
   }
   
   // returns the max item of the specified queue - recursive implementation
   private Comparable recursiveMaxItem()  // note: method reverses queue FIFO sequence!
   {
      // base case
      if (size() <= 1) return front();
      
      // simplify problem
      Comparable curFront = dequeue();
      
      // recursive call
      Comparable maxItem = recursiveMaxItem();
      
      // reinsert dequeue element
      enqueue(curFront);
      
      // select max item
      if (curFront.compareTo(maxItem) > 0) maxItem = curFront;
      
      return maxItem;
   }
          
   /**
      Returns an array that contains the elements of this extended queue in the same FIFO
      sequence as in this extended queue with the front item at index 0.
      @return an array that contains the element of this extended queue in the same FIFO
      sequence as in this extended queue if it is not empty or otherwise an empty array.
   */
   public Comparable[] toArray()
   {
      // create return array
      Comparable[] items = new Comparable[size()];
      
      // create support queue
      Queue q = new Q();
      
      // move elements from this extended queue to support queue while copying elements
      // to array
      int i = 0;
      while (!isEmpty())
      {
         items[i++] = front();   // gets front item from this queue
         q.enqueue(dequeue());   // dequeues front item and inserts it into support queue
      }
      
      // re-insert elements into this queue
      while (!q.isEmpty()) enqueue(q.dequeue());
      
      return items;      
   }
}  
