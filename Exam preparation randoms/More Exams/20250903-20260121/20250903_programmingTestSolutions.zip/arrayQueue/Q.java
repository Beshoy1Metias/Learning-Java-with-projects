/**
  *        FOUNDATIONS OF COMPUTER SCIENCE - A.A. 2024-25
  *                Programming Test - 03-09-2025
  *
  * Implements a comparable queue, that is collection of comparable
  * items with First In First Out (FIFO) access policy, where the
  * first item inserted (front item) is the first extracted.
  *
  * @author A. Luchetta
  * @version 18-Jan-2025
  *
  */
// implemented by partially filled array. Asymptotic time complexity of the dequeue
// method is O(n) in average and worst cases.
public class Q implements Queue // ADT Queue 
{
   // constants
   private static final int INITIAL_CAPACITY = 1;
   
   // instance variables
   private Comparable[] v;             // items are comparable
   private int vSize;                  // item counter
   

   /**
      Constructs an empty queue
   */
   public Q()
   {
      makeEmpty();
   }
   
   /**
      Returns true if the specified item is contained in this queue
      @param item the item to check
      @return true if the specified item is contained in this queue 
   */
   public boolean contains(Comparable item)
   {
      for (int i = 0; i < vSize; i++)
      {
         if (v[i].compareTo(item) == 0) return true;
      }
      
      return false;
   }
        
   /*
      Removes the front item from this queue and returns it.
      @return the removed front item of this queue or null if the this queue is empty.
   */
   public Comparable dequeue()
   {
      // check preconditions
      if (isEmpty()) return null;
      
      // save current front
      Comparable front = front();
      
      // move elements to the left - O(n) in average and worst cases
      System.arraycopy(v, 1, v, 0, vSize - 1);
      
      // remove duplicate
      v[vSize - 1] = null;
      
      // decrement item counter
      vSize--;
      
      return front;
   }
   
   /**
      Inserts the specified item into this queue.
      @param item the specified item to be inserted.
      @throws java.lang.IllegalArgumentException if the specified item is null.
   */
   public void enqueue(Comparable item) throws IllegalArgumentException
   {
      // check preconditions
      if (item == null) throw new IllegalArgumentException();
      
      // dynamically resize if needed 
      if (vSize >= v.length)
      {
         Comparable[] newV = new Comparable[2 * v.length];
         System.arraycopy(v, 0, newV, 0, v.length);
         v = newV;
      }
      
      // insert new element
      v[vSize] = item;
      
      // increment item counter
      vSize++;     
   }
   
   /**
      Returns the front item of this queue.
      @return the front item of this queue or null if this queue is empty.
   */
   public Comparable front()
   {
      // check preconditions
      if (isEmpty()) return null;
      
      return v[0];  
   }   
   
  /**
      Checks if this queue is empty.
      @return true if this queue is empty.
   */
   public boolean isEmpty()
   {
      return vSize <= 0;
   }
   
   /**
      Makes this queue empty.
   */
   public void makeEmpty()
   {
      // create inner array
      v = new Comparable[INITIAL_CAPACITY];
      
      // initialize item counter
      vSize = 0;   
   }        
   
   /**
      Returns the number of items in this queue.
      @return number of items in this queue.
   */
   public int size()
   {
      return vSize;
   }     
      
   /*
      Returns the maximum item in this queue according to the natural ordering
      of the elements of this queue.
      @return the maximum data item in this queue or null if this queue is empty.
   */
   public Comparable maxItem()
   {
      // preconditions
      if (isEmpty()) return null;
      
      // search for max item
      Comparable maxItem = v[0];               // initial guess     
      for (int i = 1; i < vSize; i++)
      {
         Comparable curItem = v[i];           
         if (curItem.compareTo(maxItem) > 0) maxItem = curItem;
      }
      
      return maxItem;
   }
}  
