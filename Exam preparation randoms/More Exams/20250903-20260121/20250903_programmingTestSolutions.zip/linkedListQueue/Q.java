/**
  *        FOUNDATIONS OF COMPUTER SCIENCE - A.A. 2024-25
  *                Programming Test - 03-09-2025
  *
  * Implements a queue, that is collection of items with FIFO (First In First
  * Out) access policy, where the first item inserted (front) is the first
  * extracted.
  *
  * @author A. Luchetta
  * @version 2-August-2025
  *
  */
// implemented by linked list. Asymptotic time complexity of the enqueue/dequeue methods is O(1)
// in all cases.
public class Q implements Queue // ADT Queue 
{
   
   // instance variables
   private ListNode head, tail;
   private int size;                  // item counter
   
   // inner class list node
   private class ListNode
   {
      // instance variables
      private Comparable element;
      private ListNode next;
      
      // constructs a new listnode with the specified key, value and next list node
      public ListNode(Comparable e, ListNode n)
      {
         setElement(e);
         setNext(n);
      }
      
      // constructs an empty list node
      public ListNode()
      {
         this(null, null);
      }
      
      // accessor methods
      public Comparable getElement()     { return element; }
      public ListNode getNext() { return next;   }
      
      // mutator methods
      public void setElement(Comparable e)     { element = e; }
      public void setNext(ListNode n) { next = n;    }
   }
   

   /**
      Constructs an empty queue
   */
   public Q()
   {
      makeEmpty();
   }
   
   /**
      Returns true if the specified item is contained in this queue
      @param item the item to check
      @return true if the specified item is contained in this queue 
   */
   public boolean contains(Comparable item)
   {
      // check item
      if (item == null) return false;  // null cannot be in this queue - see enqueue
      
      // scroll linked list
      ListNode n = head.getNext();
      while (n != null)
      {
         if (n.getElement().compareTo(item) == 0) return true;  // found
         n = n.getNext();
      }
      
      return false;                                             // not found
   }
        
   /*
      Removes the front item from this queue and returns it.
      @return the removed front item of this queue or null if the this queue is empty.
   */
   public Comparable dequeue() // O(1) in all cases
   {
      // check preconditions
      if (isEmpty()) return null;
      
      // save current front
      Comparable front = front();
      
      // remove element
      head = head.getNext();
      head.setElement(null);
      
      // decrement item counter
      size--;
      
      return front;
   }
   
   /**
      Inserts the specified item into this queue.
      @param item the specified item to be inserted.
      @throws java.lang.IllegalArgumentException if the specified item is null.
   */
   public void enqueue(Comparable item) throws IllegalArgumentException // O(1) in all cases
   {
      // check preconditions
      if (item == null) throw new IllegalArgumentException();
           
      // insert new element
      tail.setNext(new ListNode(item, null));
      tail = tail.getNext();
      
      // increment item counter
      size++;     
   }
   
   /**
      Returns the front item of this queue.
      @return the front item of this queue or null if this queue is empty.
   */
   public Comparable front()
   {
      // check preconditions
      if (isEmpty()) return null;
      
      return head.getNext().getElement();   
   }   
   
  /**
      Checks if this queue is empty.
      @return true if this queue is empty.
   */
   public boolean isEmpty()
   {
      return size <= 0;
   }
   
   /**
      Makes this queue empty.
   */
   public void makeEmpty()
   {
      // create inner array
      head = tail = new ListNode();
      
      // initialize item counter
      size = 0;   
   }        
   
   /**
      Returns the number of items in this queue.
      @return number of items in this queue.
   */
   public int size()
   {
      return size;
   }     
      
   /*
      Returns the maximum item in this queue according to the natural ordering
      of the elements of this queue.
      @return the maximum data item in this queue or null if this queue is empty.
   */
   public Comparable maxItem()
   {
      // preconditions
      if (isEmpty()) return null;
      
      // guess max item
      Comparable max = head.getNext().getElement();
      
      // check all other items
      ListNode n = head.getNext().getNext();
      while (n != null)
      {
         if (max.compareTo(n.getElement()) < 0)
         {
            max = n.getElement();
         }
         
         n = n.getNext();
      }
      
      return max;   
   }
}  
