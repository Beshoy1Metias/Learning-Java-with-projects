// FOUNDATIONS OF COMPUTER SCIENCE
// Exam dated 2 July 2025

/**
   Implements a stack that is a data container where data is inserted/extracted by
   using the Last-in-First-out data policy.
   
   @author A.Luchetta
   @version 26 June 2025
*/
public class S implements Stack
{
   // private part
   private ListNode head;   // tail is not necessary
   private int size;
   
   // inner class
   private class ListNode
   {
      private Object element;
      private ListNode next;
      
      // constructors
      public ListNode(Object e, ListNode n) { element = e; next = n; }
      public ListNode() { this(null, null); }
      
      // accessor methods
      public Object getElement() { return element; }
      public ListNode getNext() { return next;}
      
      // mutator methods
      public void setElement(Object e) { element = e;}
      public void setNext(ListNode n) { next = n; }
   }
   
   /**
      Initializes an empty stack
   */
   public S()
   {
      makeEmpty();
   }
   
   /**
      Checks if this stack contains the specified item.
      @param item the specified item to be checked
      @return true if this stack contains the specified item      
   */
   public boolean contains(Object item) // O(n) in the average and worst cases
   {
      // linear search
      ListNode n = head.getNext();
      while (n != null)
      {
         if (n.getElement().equals(item)) return true;
         n = n.getNext();
      }
      
      return false;
   }

   /**
      Returns true if this stack is empty
      @return true if this stack is empty.
   */
   public boolean isEmpty()
   {
      return size <= 0;
   }
   
   /**
      Makes this set empty.
   */
   public void makeEmpty()
   {
      head = new ListNode();
      size = 0;
   }

   /**
      Removes the object at the top of this stack and returns that object as
      the value of this function.
      @return The object at the top of this stack.
      @throws EmptyStackException if this stack is empty
   */
   public Object pop() throws EmptyStackException // O(1) in all cases
   {
      // preconditions
      if (isEmpty()) throw new EmptyStackException();
      
      // store item to return
      Object ret = head.getNext().getElement();
      
      // remove item
      head = head.getNext();
      head.setElement(null);
      
      // decrement item counter
      size--;
      
      return ret;
   }
   
   /**
      Pushes an item onto the top of this stack, if not null.
      @param item the item to be pushed onto this stack.
   */
   public void push(Object item)  // O(1) in all cases
   {
      // preconditions
      if (item == null) return;
      
      // push item
      head.setElement(item);
      head = new ListNode(null, head);
      
      // increment item counter
      size++;
   }
   
   /**
      Returns the number of item in this stack.
      @return the number of item in this stack
   */
   public int size()
   {
      return size;
   }   
   
   /**
      Looks at the object at the top of this stack without removing it from the
      stack.
      @return the object at the top of this stack.
      @throws EmptyStackException if this stack is empty. 
   */
   public Object top() throws EmptyStackException  // O(1) in all cases
   {
      // preconditions
      if (isEmpty()) throw new EmptyStackException();
      
      return head.getNext().getElement();
   }
}
