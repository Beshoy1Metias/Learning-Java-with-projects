// FOUNDATIONS OF COMPUTER SCIENCE
// Exam dated 2 July 2025

/**
   Implements a stack that is a data container where data is inserted/extracted by
   using the Last-in-First-out data policy.
   
   @author A.Luchetta
   @version 26 June 2025
*/
public class S implements Stack
{
   // private part
   private static final int INITIAL_CAPACITY = 1;
   private Object[] v;
   private int vSize;
   
   /**
      Initializes an empty stack
   */
   public S()
   {
      makeEmpty();
   }
   
   /**
      Checks if this stack contains the specified item.
      @param item the specified item to be checked
      @return true if this stack contains the specified item      
   */
   public boolean contains(Object item) // O(n) in the average and worst cases
   {
      // linear search
      for (int i = 0; i < vSize; i++)
      {
         if (v[i].equals(item)) return true;
      }
      
      return false;
   }

   /**
      Returns true if this stack is empty
      @return true if this stack is empty.
   */
   public boolean isEmpty()
   {
      return vSize <= 0;
   }
   
   /**
      Makes this set empty.
   */
   public void makeEmpty()
   {
      v = new Object[INITIAL_CAPACITY];
      vSize = 0;
   }

   /**
      Removes the object at the top of this stack and returns that object as
      the value of this function.
      @return The object at the top of this stack.
      @throws EmptyStackException if this stack is empty
   */
   public Object pop() throws EmptyStackException // O(1) in all cases
   {
      // preconditions
      if (isEmpty()) throw new EmptyStackException();
      
      // store item to return
      Object ret = v[vSize - 1];
      
      // remove item
      v[vSize - 1] = null;
      
      // decrement item counter
      vSize--;
      
      return ret;
   }
   
   /**
      Pushes an item onto the top of this stack, if not null.
      @param item the item to be pushed onto this stack.
   */
   public void push(Object item)  // O(1) in the average case, O(n) in the worst case
   {
      // preconditions
      if (item == null) return;
      
      // dynamically resize if needed
      if (vSize >= v.length)  // O(n)
      {
         Object[] newV = new Object[2 * v.length];
         System.arraycopy(v, 0, newV,0, v.length);  // O(n) operation
         v = newV;
      }
      
      // push item
      v[vSize] = item;
      
      // increment item counter
      vSize++;
   }
   
   /**
      Returns the number of item in this stack.
      @return the number of item in this stack
   */
   public int size()
   {
      return vSize;
   }   
   
   /**
      Looks at the object at the top of this stack without removing it from the
      stack.
      @return the object at the top of this stack.
      @throws EmptyStackException if this stack is empty. 
   */
   public Object top() throws EmptyStackException  // O(1) in all cases
   {
      // preconditions
      if (isEmpty()) throw new EmptyStackException();
      
      return v[vSize - 1];
   }
}
