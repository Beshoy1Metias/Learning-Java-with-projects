/**
   Implements an extended set.
      
   Type Parameters:
      @param <E> the parametric type of data items in this extended set.
      
   @see S
      
   @author A. Luchetta
   @version 11 Jan. 2025
*/
public class SE<E extends Comparable<E>> extends S<E>
{
   /**
      Constructs an empty extended set.
   */
   public SE()
   {
      //TODO
   }
   
   /**
      Overrides the superclass method of the same name using a recursive algorithm.
      @param item the item to check.
      @return true if this extended set contains the specified item.
   */
   @Override
   public boolean contains(Object o)
   {
      // TODO
      
      return super.contains(o);

   }
   
   /**
      Compares the specified object with this extended set for equality.
      @param o the specified object.
      @return true if the specified object equals this extended set.
   */
   @Override
   public boolean equals(Object o)
   {
        //TODO
        
        return true;                              // sets are equal
   }     
   
   /**
      Returns an array containing the data item of this extended set sorted in ascending
      order according to their natural order.
      @return an array containing the data item of this set sorted according to their
              natural order or an empty array if this extended set is empty
   */
   public Object[] toSortedArray()
   {
      // TODO
      
      return null;
   }
}
