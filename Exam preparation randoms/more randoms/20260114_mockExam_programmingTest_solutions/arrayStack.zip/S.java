/**
  * Implements the Stack Abstract Data Type, that is, a data container that
  * enforces the Last In First Out (LIFO) data handling policy.
  *
  * @param <E> the parametric type of the stack elements
  * @see Stack
  * @see EmptyStackException
  *
  * @author A. Luchetta
  * @version 07-Jan-2026
  */
// implementation by partially filled array
public class S<E> implements Stack<E>
{
   // constants
   private static final int INITIAL_CAPACITY = 16;
   
   // instance variables
   private Object[] v;     // array of objects
   private int vSize;      // stack element counter
   
   /**
      Constructs an empty stack.
   */
   public S()
   {
      // initialize inner array
      v = new Object[INITIAL_CAPACITY];
      
      // initialize element counter      
      vSize = 0;
   }
   
   /**
      Returns the minimum element in this stack based on the natural order
      of stack elements.
      @return the minimum element in this stack.
      @throws EmptyStackException if this stack is empty.
   */
   public E getMin()
   {
      // check preconditions
      if (isEmpty())
      {
         throw new EmptyStackException("missing maximum element in empty stack");
      }
      
      // search for minimum
      E curMin = (E)v[0];    // assumes that min element is at index 0
      for (int i = 0; i < vSize; i++)
      {
         // selct current element
         Comparable curItem = (Comparable) v[i];  // type cast is needed
         
         // check if current element is new minimum
         if (curItem.compareTo(curMin) < 0)
         {
            curMin = (E)curItem;  // type cast is needed
         }
      }
      
      return curMin;
   }

   /**
      Returns true if this stack contains no elements.
      @return true if this stack contains no elements.
   */
   public boolean isEmpty()
   {
      return vSize <= 0;    
   }
   
   /**
      Returns the number of elements in this stack.
      @return the number of elements in this stack.
   */
   public int size()
   {
      return vSize;
   }
   
   /**
     Removes the object at the top of this stack and returns it.
     @return the object at the top of this stack.
     @throws EmptyStackException if this stack is empty.
   */  
   public E pop() throws EmptyStackException
   {
      // take advantage of top method
      E curTop = top();   // can throw EmptyStackException
      
      // remove top-most element
      v[vSize - 1] = null;
      
      // update stack element counter
      vSize--;
           
      return curTop;
   }
   
   /**
     Pushes an element onto the top of this stack.
     @param element the element to be pushed onto this stack.
     @throws java.lang.IllegalArgumentException if the specified element is
            null.
     @throws java.lang.ClassCastException if the data type of the specified
            element is not a class that implements the Comparable interface.
   */
   public void push(E element)
   {
      // check preconditions - null element cannot be pushed into this stack
      if (element == null)  
      {
         throw new IllegalArgumentException("element is null");
      }
      
      if (!(element instanceof Comparable)) // non Comparable elements cannot 
      {                                     // be pushed into this stack
         throw new ClassCastException("element is not Comparable");
      }
      
      // dynamically resize if needed
      if (vSize >= v.length)
      {
         Object[] newV = new Object[2 * v.length];
         System.arraycopy(v, 0, newV, 0, v.length);
         v = newV;
      }
      
      // insert new top element
      v[vSize] = element;
      
      // update stack element counter
      vSize++;
   }

   /**
     Looks at the object at the top of this stack without removing it from the
     stack.
     @return the object at the top of this stack.
     @throws EmptyStackException if this stack is empty.
   */ 
   public E top() throws EmptyStackException
   {
      // check preconditions
      if (isEmpty())
      {
         throw new EmptyStackException();
      }
      
      // select stack top-most element
      E curTop = (E)v[vSize - 1];   // type cast is needed
      
      return curTop;
   }
}
