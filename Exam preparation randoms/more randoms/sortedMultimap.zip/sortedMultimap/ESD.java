/**
  * Implements an extended SortedMultimap
  *
  * param K parametric type limited to Comparable for the key 
  * param V parametric type limited to Comparable for the value
  *
  * @author A. Luchetta
  * @version 12-02-2019
  *
  */
public class ESD<K extends Comparable,V extends Comparable> extends D<K,V>
{      
   /**
     * checks if there is at least a mapping for the key in this multimap
     * @param key the key specified
     * @return true if this multimap contains a mapping with the specified key,
     *         otherwise false
     */
   public boolean contains(K key)
   {
      // TODO
      
      return false;
   }
 
   /**
     * retrieves the unique keys in this map
     * @return  a sorted array containing the keys in this multimap
     */
   public Comparable[] keySet()
   {
      // TODO
            
      return null;
   } 
   
   /**
     * Retrieves the sorted non-duplicated value in this multimap
     * @return a sorted array containing the values of this multimap without duplicates
     * multimappa
     */
   public Comparable[] valueSet()
   {
      // TODO
      
      return null;
   }    
}
