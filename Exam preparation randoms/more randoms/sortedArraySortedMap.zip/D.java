/**
  * Defines the Sorted Multimap abstract data type, i.e. a data container of
  * key/value mappings in which the key may not be unique.
  * The key and value are of parametric types and the key is limited to
  * Comparable
  *
  *
  * param K parametric type limited to Comparable for the key 
  * param V parametric type for the value
  *
  * @author A. Luchetta
  * @version 27-12-2020
  *
  */
public class D<K extends Comparable,V> implements SortedMultimap<K,V>
{   
   // constants
   private static final int INITIAL_CAPACITY = 1;
   
   // instance variables
   private Object[] v;     // array of objects
   int vSize;              // mapping counter
   
   // inner class Entry
   private class Entry
   {
      private K key;
      private V value;
      
      // constructor
      public Entry(K aKey, V aValue)
      {
         setKey(aKey);
         setValue(aValue);         
      }
      
      // accessor metods
      public K getKey() { return key; }
      public V getValue() { return value; }
      
      // mutator methods
      public void setKey(K aKey) { key = aKey; }
      public void setValue(V aValue) { value = aValue;}
   }
   
   /**
      Constructs an empty multimap
      */
      public D()
      {
         makeEmpty();
      }

   /**
      checks if this container is empty
      @return true if this container is empty
  */
   public boolean isEmpty()
   {
      return vSize <= 0;
   }

   /**
      makes this container empty
   */
   public void makeEmpty()
   {
         v = new Object[INITIAL_CAPACITY]; // array of objects
         vSize = 0;  
   }

   /**
      returns the number of data items in this container
      @return the number of data items in this container
   */
   public int size()
   {
         return vSize;
   }

   /**
     * Returns an array containing all the values mapped to the specified key in
     * this multimap
     * @param key the specified key whose mapped values to return
     * @return an array containing all the values mapped to the specified key in
     *         this multimap if this multimap contains mappings for the key,
     *         otherwise an empty array
     */ 
   // O(logn + k) where k is the number of mappings with the specified key
   // O(logn) for binary search, k for the amount of values with same key copied 
   // O(n)in whorst case, when all mappings have the same key (k = n)
   // O(logn) when there only one mapping or no mappings for the key
   public Object[] findAll(K key)
   {
      // search key
      int index = search(key);  // searches by binary search - O(logn)
      
      // case key is not in the multimap
      if (index < 0)
      {
         return new Object[0];  // empty array
      }
      
      // case key is in the map - other mappings with same key may be on the
      // left and/or right of index
      
      // search on the left-hand side
      int i = index - 1;
      while (i >= 0)
      {
         // get current key
         Entry curEntry = (Entry)v[i];
         K curKey = curEntry.getKey();
         
         // check if curKey and key are the same
         if (!curKey.equals(key)) // check whether curKey and key are different
         {
            break;
         }
         
         // decrement index to serach further on the left
         i--;
      }
      
      // compute min index with specified key
      int minIndx = i + 1;
      
      // search at the right-hand side
      i = index + 1;
      while (i < vSize)
      {
         // get current key
         Entry curEntry = (Entry)v[i];
         K curKey = curEntry.getKey();
         
         // check if curKey and key are the same
         if (!curKey.equals(key))
         {
            break;
         }
         
         // search further on the right
         i++;
      }  
      
      // compute max index with specified key
      int maxIndx = i - 1;

      // compute value count with same key
      int keyCount = maxIndx - minIndx + 1; 

     // define return array
     Object[] result = new Object[keyCount];

     // copy values into return array
     for (int j = 0; j < result.length; j++)
     {
        Entry curEntry = (Entry)v[minIndx + j];
        result[j] = curEntry.getValue();        
     }              
       
      return result;
   }
   
   // binary search
   private int search(K aKey)
   {
      // null key cant be in the multimap
      if (aKey == null)
      {
         return -1;
      }
      
      return search(v, 0, vSize - 1, aKey);
   }
   
   private int search(Object a, int from, int to, K key)
   {
      // base case
      if (from > to)
      {
         return -1;
      } 

      // approx in the middle
      int mid = (from + to) / 2;
      Entry midEntry = (Entry)v[mid]; 
      K midKey = midEntry.getKey();
      
      // base case
      if (midKey.compareTo(key) == 0)
      {
         return mid;
      } 
      // recursive step
      else if (midKey.compareTo(key) < 0)
      {
         return search(v, mid + 1, to, key); // search right
      } 
      else
      {
         return search(v, from, mid - 1, key); // search left
      }         
   }
   
   /** 
     * Maps the specified value to the specified key in this multimap
     * @param key the specified key
     * @param value the specified value
     * @throws java.lang.IllegalArgumentException if the specified key or value
     *         is null
     */
   public void insert(K key, V value)
   {
      // check preconditions
      if (key == null || value == null)
      {
         throw new IllegalArgumentException("key or value is null");
      }
      
      // dynamically resize if needed
      if (vSize >= v.length)
      {
         Object[] newV = new Object[2 * v.length]; // array of objects
         System.arraycopy(v, 0, newV, 0, v.length);
         v = newV;
      }
      
      // insert new mapping keeping the array sorted
      int j = vSize - 1;
      while (j >= 0 && key.compareTo(((Entry)v[j]).getKey()) < 0)
      {
         v[j + 1] = v[j];
         j--;
      }     
      v[j + 1] = new Entry(key, value);
      
      // increment mapping counter
      vSize++;     
   }   
  
   /**
     * Returns the keys in this multimap
     * @return a sorted array containing the keys of this map if this multimap
     *         is not empty, otherwise an empty array
     */
   public Comparable[] keys()
   {
      // define return array
      Comparable[] keys = new Comparable[vSize];
      
      // copy keys into return array
      for (int i = 0; i < vSize; i++)
      {
         Entry curEntry = (Entry)v[i];
         keys[i] = curEntry.getKey();
      }

      return keys;
   }   
        
   /**
     * Removes from this multimap all the mappings of the specified key and 
     * return the mapped values in an array
     * @param key the specified key
     * @return an array containing the values mapped to the specified key,
     *         if any, otherwise an empty array
     */   
   public Object[] removeAll(K key)
   {
      // get return array
      Object[] ret = findAll(key);
   
      // remove objects
      while (remove(key) != null)
      {
         ;  // does nothing - do-nothing statement     
      }

      return ret;
   } 

   // removes an entry with the specified key
   private V remove(K key)
   {
      // search key
      int index = search(key);

      // case the key is not in the multimap
      if (index < 0)
      {
         return null;
      }   

      // case the key is in the map
      // save temporarily value
      Entry curEntry = (Entry)v[index];
      V old = curEntry.getValue();
      
      //remove mapping with specified key 
      for (int i = index; i < vSize - 1; i++) 
      {
         v[i] = v[i + 1];  // sequence matters!
      } 

      // clear duplicated entry
      v[vSize - 1] = null;

      // decrement entry counter
      vSize--;

      return old;      
   }   
}
