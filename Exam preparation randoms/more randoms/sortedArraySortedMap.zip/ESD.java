/**
  * Implements an extended SortedMultimap
  *
  * param K parametric type limited to Comparable for the key 
  * param V parametric type limited to Comparable for the value
  *
  * @author A. Luchetta
  * @version 12-02-2019
  *
  */
public class ESD<K extends Comparable,V extends Comparable> extends D<K,V>
{      
   /**
      Constructs an empty extended multimap
   */
   public ESD()
   {
      super();
   }

   /**
     * checks if there is at least a mapping for the key in this multimap
     * @param key the key specified
     * @return true if this multimap contains a mapping with the specified key,
     *         otherwise false
     */
   public boolean contains(K key)
   {
      // get values for the specified key
      Object[] values = findAll(key);
      
      return values.length >= 0;  // returns true if the array is not empty
   }
 
   /**
     * retrieves the unique keys in this map
     * @return  a sorted array containing the keys in this multimap
     */
   public Comparable[] keySet()
   {
      // get keys
      Comparable[] keys = keys(); // returns sorted keys
      
      // remove duplicates
      Comparable[] uniqueKeys = new Comparable[size()]; // max possible length
      int uniqueKeysSize = 1;
      uniqueKeys[0] = keys[0];
      for (int i = 1; i < keys.length; i++)
      {
         if (!keys[i].equals(uniqueKeys[uniqueKeysSize - 1]))
         {
            uniqueKeys[uniqueKeysSize++] = keys[i];
         }
      }
      
      // resize to get full array
      Comparable[] result = new Comparable[uniqueKeysSize];
      System.arraycopy(uniqueKeys, 0, result, 0, result.length );
            
      return result;
   } 
   
   /**
     * Retrieves the sorted non-duplicated value in this multimap
     * @return a sorted array containing the values of this multimap without duplicates
     */
   public Comparable[] valueSet()
   {
      // define auxiliary multimap
      ESD<V, V> aux = new ESD();
      
      // get unique keys
      Comparable[] keys = keySet();
      
      // get values associated to keys
      for (int i = 0; i < keys.length; i++)
      {
         // get values associated to current key
         Object[] someValues = findAll((K)keys[i]); // type cast is needed
         
         // insert values into aux multimap
         for (int j = 0; j < someValues.length; j++)
         {
            aux.insert((V)someValues[j], (V)someValues[j]); // type cast is needed
         }
      }
      
      // get unique values
      Comparable[] result = aux.keySet();
      
      return result;     
   }    
}
