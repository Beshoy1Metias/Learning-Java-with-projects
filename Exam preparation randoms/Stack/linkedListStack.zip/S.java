/*
   Foundations of Computer Science
   Programming Test - 1 February 2023
*/
/**  
   Implements the Stack abstract data type with Last In First Out (LIFO) data
   access mode. 
   
   T is the parametric type of the stack items
   
   @see Stack
   @see EmptyStackException
*/
/* Implementation using a linked list */
public class S<T> implements Stack<T> // Stack data structure
{  
   // instance variables
   private ListNode head;
   private int size;
   
   // inner class
   private class ListNode
   {
      // instance variables
      private T element;
      private ListNode next;
      
      // constructore
      public ListNode(T e, ListNode n)
      {
         setElement(e);
         setNext(n);
      }
      
      public ListNode()
      {
         this(null, null);
      }
      
      // accessor method
      public T getElement() { return element; }
      public ListNode getNext() { return next; }
      
      // mutator methods
      public void setElement(T e) { element = e; }
      public void setNext(ListNode n) { next = n;}     
   }
   
   /**
      Constucts an empty stack
   */
   public S()
   {
      makeEmpty();
   }

   /*
      removes the top item from this stack and returns it 
      @return the top item removed from this stack
      @throws EmptyStackException if this stack is empty
   */
   public T pop() throws EmptyStackException // as method removeFirst in linkedList
   {
      // temporarily store the element to remove
      T ret = top();  // can throw EmptyStackException
      
      // advance head
      head = head.getNext();
      
      // remove element from head
      head.setElement(null);
      
      // decrement counter
      size--;
      
      return ret;
   } 
   
   /**
      inserts the specified item at the top of this stack
      @param x the specified item to be inserted
      @throws java.lang.IllegalArgumentException if the specified item is null
   */
   public void push(T x) throws IllegalArgumentException  // as addFirst in LinkedList
   {
      // check preconditions
      if (x == null) throw new IllegalArgumentException();
      
      // insertion element into list node head
      head.setElement(x);
           
      // create new node with next pointing to head node
      ListNode n = new ListNode(null, head);
      
      // set new node to be the new head node
      head = n;
      
      // increment counter
      size++;
   }
   
   /**
      Returns the position of an object in the stack. If the object x is present
      in the stack, the method returns the distance from the top of the stack to
      the nearest occurrence of x. The topmost item on the stack is considered
      to be at distance 0.
      @param x the desired object
      @return the position from the top of the stack where the object is
              located; -1 indicates that the object is not in this stack.    
   */
   public int search(T x)
   {
      // linear search
      int i = 0;
      ListNode n = head.getNext();   // first node in the linked list with a data item
      while (n != null)
      {
         if (n.getElement().equals(x))  // cannot throw NullPointerException
         {
            return i;           // found
         }
         
         i++;                   // increments distance from top element
         
         n = n.getNext();       // advance n: next node to process
      }
      
      return -1;                // not found
   }   
   
   /**
      returns the top item of this stack
      @return the top item of this stack
      @throws EmptyStackException if this stack is empty
   */
   public T top() throws EmptyStackException // as getFirst
   {
      // check precondition
      if (isEmpty()) throw new EmptyStackException();
      
      // select and return top item
      return head.getNext().getElement();
   }
   
  /**
      checks if this stack is empty
      @return true if this stack is empty, false otherwise
   */
   public boolean isEmpty()
   {
      return head.getNext() == null;  // in alternative we can check variable size
   }                                  // return size <= 0; 
   
   /**
      returns the number of items in this stack
      @return number of items in this stack
   */
   public int size()
   {
      return size;
   }  
   
   /**
      Makes this stack empty
   */
   public void makeEmpty()
   {
      head = new ListNode();
      size = 0;   
   }
   
   /**
      returns an array containing the items of this stack in the LIFO
      sequence with the top of this stack at index zero. The size of the array
      is equal to the number of items present in this stack 
      @return an array containing the items of this stack, if the stack is
              not empty, otherwise an empty array
   */
   public Object[] toArray()
   {
      // define return array
      Object[] v = new Object[size];
      
      // inspect stack elements
      int i = 0;
      ListNode n = head.getNext(); // first node with data in the linked list
      while (n != null)            // until we reach the end of the linked list
      {
         v[i++] = n.getElement();  // copies the element into the return array
                                   // and increments the array index
         n = n.getNext();          // moves n ahead: next node to process
      }
          
      return v;
   }
}  
