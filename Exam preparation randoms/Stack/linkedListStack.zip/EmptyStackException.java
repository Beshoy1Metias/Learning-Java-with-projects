/*
   Foundations of Computer Science
   Programming Test - 1 February 2023
*/
/** 
   Defines the Exception for an Empty stack
   Thrown by methods in the Stack data structure to indicate that the stack is 
   empty
*/
public class EmptyStackException extends RuntimeException
{
   /**
      Constructs a new EmptyStackException without diagnostic messages
   */
   public EmptyStackException()
   {
   }

   /**
      Constructs a new EmptyStackException with the specified diagnostic message
      @param message the specified diagnostic message
   */
   public EmptyStackException(String message)
   {
      super(message);
   }
}
