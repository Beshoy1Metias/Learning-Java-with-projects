/** FOUNDATIONS OF COMPUTER SCIENCE
  * PROGRAMMING TEST DATED 3-July-2019
  *
  * Implements a list of parametric data types.
  *
  * @param E - the parametric type of the elements in the list.
  *
  * @see List
  *
  * @author A. Luchetta
  * @version 18-06-2019
  */
public class L<E> implements List <E>
{
   // constants
   private static final int INITIAL_CAPACITY = 1; // any positive integer
   
   // instance variables
   private Object[] v;               // array of objects
   private int vSize;                // element counter
   
   /**
      Constructs an empty list
   */
   public L()
   {
      makeEmpty();
   }

   /**
      checks if this container is empty.
      @return true if this container is empty.
   */
   public boolean isEmpty()
   {
      
      return vSize <= 0;
   }

   /**
      makes this container empty.
   */
   public void makeEmpty()
   {
      v = new Object[INITIAL_CAPACITY];
      vSize = 0;      
   }

   /**
      returns the number of data items in this container.
      @return the number of data items in this container.
   */
   public int size()
   {     
      return vSize;
   }
   
   /**
     Inserts the specified element at the last position in this list.
     @param element the specified element to be added.
     @throws java.lang.IllegalArgumentException if the specified element is null.                 
   */
   public void add(E element)
   {
      // take advantage of the add(int index, E element) method
      add(vSize, element);  // can throw IllehalArgumentException
   }
   
 /**
     Inserts the specified element at the specified position in this list
     Shifts the element in that position and the following elements to the right
     (adds 1 to the indeces).
     @param index the specified position.
     @param element the specified element.
     @throws java.lang.IndexOutOfBoundsException if the the specified position
             is outside the valid range [0, number of elements in the list].
     @throws IllegalArgumentException if the specified element is null.                   
   */
   public void add(int index, E element)   
   {
      // check preconditions
      if (element == null)
      {
         throw new IllegalArgumentException("element is null");
      }
      
      if (index < 0 || index > vSize)
      {
         throw new IndexOutOfBoundsException("index is invalid");  
      }
      
      // dynamically resize if needed
      if (vSize >= v.length)
      {
         Object[] newV = new Object[v.length * 2];
         System.arraycopy(v, 0, newV, 0, v.length);
         v = newV;
      }
      
      // shift elements to the right
      for (int i = vSize; i > index; i--)
      {
         v[i] = v[i - 1];
      }
      
      // insert new element and update element counter
      v[index] = element;
      vSize++;
   }
     
   /**
      Returns the element at the specified position in this list.
      @param index the specified position.
      @return the element at the specified position.
      @throws java.lang.IndexOutOfBoundsException if the the specified position
              is outside the valid range [0, number of elements in the list - 1]. 
   */
   public E get(int index)
   {
      // check preconditions
      if (index < 0 || index >= vSize)
      {
         throw new IndexOutOfBoundsException("index is not valid");
      }
      
      // select return element
      E curElement = (E)v[index];  // type cast is needed
      
      return curElement;
   }
   
   /**
      Returns an iterator over the elements of type T.
      @return an iterator over the elements in a list in proper sequence.
   */
   public Iterator<E> iterator()
   {
      return new ArrayListIterator<E>();
   }
   
   // inner class ArrayListIterator
   // Note:the position of the iterator is the index where the next element is
   private class ArrayListIterator<T> implements Iterator<T>
   {
      // variables
      private static final int ILLEGAL_STATE = -1;
      
      // instance variables
      private int current;
      private int previous;
      
      // constructs an iterator positioned at the beginning of this list
      public ArrayListIterator()
      {
         current = 0;              // sets the position to beginning of sequence
         previous = ILLEGAL_STATE; // prevents calling the remove method
      }
      
      /**	
         Returns true if the iteration has more elements.
         @return true if the  iterator has more elements.   
      */
      public boolean hasNext()
      {
         return current < vSize;
      }
   
      /**
         Returns the next element in the sequence and moves the iterator
         forward.
         @return the next element in the sequence.
         @throws java.util.NoSuchElementException if the iteration has no more
                 elements.
      */
      public T next()
      {
         // check preconditions
         if (!hasNext())
         {
            throw new java.util.NoSuchElementException("no next element in the iteration");
         }
         
         // select return element
         T nextElement = (T)v[current];  // type cast is needed
         
         // move iterator forward
         previous = current;      // allows calling the remove method
         current++;
         
         return nextElement;
      }
   
      /**
         Removes the last element returned by this iterator.
         This call can only be made once per call to next.
         @throws java.lang.IllegalStateException if next has not been called, or
                 remove has been called after the last call to next.
      */
      public void remove()
      {
         // check preconditions
         if (previous == ILLEGAL_STATE)
         {
            throw new IllegalStateException("remove withoutr next");
         }  
        
         // shift elements to the left
         for (int i = previous; i < vSize - 1; i++) 
         {
            v[i] = v[i + 1];
         } 

         // set current and previous
         current = previous;
         previous = ILLEGAL_STATE;   // prevents calling the remove method again

         // update element counter
         vSize--;         
      }
   }
      
   /**
      Returns the position of the specified element if it exists in this list.
      @param element the specified element.
      @return the position of the first occurrence of the specified element in
              this list or -1 if the element is not present in this list.
   */
   public int rankOf(E element)
   {
      // search for element
      for (int i = 0; i < vSize; i++)
      {
         if (v[i].equals(element))  // works even if element is null because
         {                          // equals return false when element is null
            return i;
         }
      }
      
      return -1;
   }   
   
   /**
      Returns an array containing the elements of this list in the sequence in
      which they are in this list.
      @return an array containing the elements of this list in the sequence in
              which they are in this list.
   */
   public Object[] toArray()
   {
      // note: never return the inner array. The following statement (commented)
      // violate the incapsulation
      // return v;  // varray is exposed outside this class!
      
      // define return array
      Object[] result = new Object[vSize];
      
      // copy elements
      System.arraycopy(v, 0, result, 0, result.length);
      
      return result;
   }
}
