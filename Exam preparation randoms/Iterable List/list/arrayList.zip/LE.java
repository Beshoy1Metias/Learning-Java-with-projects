/** FOUNDATIONS OF COMPUTER SCIENCE
  * PROGRAMMING TEST DATED 3-July-2019
  *
  * Implements an extended list of parametric data types.
  *
  * @param <E> - the parametric type of the elements in the extended list.
  *
  * @see L
  *
  * @author A. Luchetta
  * @version 10-01-2025
  */
public class LE<E extends Comparable> extends L<E>
{
   /**
      Constructs an empty extended list
   */
   public LE()
   {
      super();
   }

   // NOTE: this class inherits all features from the super class. So, do not define
   //       instance variables with the same names as the superclass instance variables. 

   /**
      Returns the rank of the first occurrence of the specified element in the sorted
      list or -1 if the element is not present in this list.
      @param element the element whose rank is to be returned.
      @return the rank of the specified element if present in the list, otherwise -1.
   */
   public int rankOfSortedList(E element)
   {
      // check preconditions - null can't be in this list
      if (element == null)
      {
         return -1;
      }
      
      // get sorted list and array
      List<E> l = toSortedList();       // gets sorted list
      Object[] listArray = l.toArray(); // gets sorted array
      
      // binary search
      int index = search(listArray, element);
      
      return index;
   }
   
   // binary search
   private static int search(Object[] a, Comparable target)
   {
      // initialize index range
      int from = 0;
      int to = a.length - 1;
      
      while (from <= to)
      {
         int mid = (from + to) / 2;
         Object midElement = a[mid];
            
         if (target.compareTo(midElement) == 0) 
         {
            return mid;
         }
         else if (target.compareTo(midElement) < 0)
         {
            to = mid - 1;
         }
         else
         {
            from = mid + 1;
         }
      }
      
      return -1;
   }
   
   /**
      Returns a list containing the same elements as this list arranged in ascending order
      according to their natural order.
      @return a list containing the same elements as this list arranged in ascending order
              according to their natural order.
   */
   public List<E> toSortedList()
   {
      // define return list
      List<E> l = new LE();
      
      // get elements
      Object[] s = toArray();
      
      // sort list elements
      sort(s);
      
      // insert elements into return list
      for (int i = 0; i < s.length; i++)
      {
         // get current element
         E curElement = (E)s[i];  // type cast is needed
         
         // add current element
         l.add(i, curElement);
      }
     
     return l;
   } 
   
   // sorts array
   private static void sort(Object[] a)
   {
      // base case
      if (a.length < 2)
      {
         return;
      }
      
      // define left and right array
      int mid = a.length / 2;
      Object[] left = new Object[mid];
      Object[] right = new Object[a.length - mid]; 
      System.arraycopy(a, 0, left, 0, left.length);
      System.arraycopy(a, mid, right, 0, right.length);
      
      // perform recursive calls
      sort(left);
      sort(right);
      
      // merge
      merge(a, left, right);
   }
   
   // merge
   private static void merge(Object[] a, Object[] b, Object[] c)
   {
      int ia = 0, ib = 0, ic = 0;

      while (ib < b.length && ic < c.length)
      {
         // get current comparable item
         Comparable bItem = (Comparable)b[ib]; // type cast is needed
         if (bItem.compareTo(c[ic]) <= 0)
         {
            a[ia++] = b[ib++];
         }
         else
         {
            a[ia++] = c[ic++];
         }
      } 

      while (ib < b.length)
      {
         a[ia++] = b[ib++];
      }
      
      while (ic < c.length)
      {
         a[ia++] = c[ic++];
      }      
   }
}